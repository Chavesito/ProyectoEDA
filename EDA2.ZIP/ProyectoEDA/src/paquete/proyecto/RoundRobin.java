/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package paquete.proyecto;

/**
 *
 * @author Usuario
 */
public class RoundRobin 
{
    Cola procesos;
    int quantum;

    public RoundRobin(Cola procesos, int quantum) {
        this.procesos = procesos;
        this.quantum = quantum;
    }

    

    public Cola getProcesos() {
        return procesos;
    }

    public void setProcesos(Cola procesos) {
        this.procesos = procesos;
    }

    public int getQuantum() {
        return quantum;
    }

    public void setQuantum(int quantum) {
        this.quantum = quantum;
    }
    
    
    
    public static void ejecutarRoundRobin(Cola procesos, int quantum) {
        while (!procesos.estaVacia()) {
            Proceso procesoActual = (Proceso) procesos.desencolar();
            int tiempoEjecucion = Math.min(quantum, procesoActual.getTiempoRestante());

            System.out.println("Ejecutando " + procesoActual.getNombre() + " por " + tiempoEjecucion + " unidades de tiempo.");

            procesoActual.disminuirTiempoRestante(tiempoEjecucion);

            if (procesoActual.getTiempoRestante() > 0) {
                procesos.encolar(procesoActual); // Vuelve a encolar el proceso
            } else {
                System.out.println(procesoActual.getNombre() + " ha terminado su ejecución.");
            }
        }
        
    }

    
}
